import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositeAmountComponent } from './deposite-amount.component';

describe('DepositeAmountComponent', () => {
  let component: DepositeAmountComponent;
  let fixture: ComponentFixture<DepositeAmountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositeAmountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositeAmountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
