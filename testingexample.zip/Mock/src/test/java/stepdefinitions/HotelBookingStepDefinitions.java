package stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Hotelbean.Hotelbookingbean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinitions {

	private WebDriver driver;
	
	private Hotelbookingbean bookingbean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\vdivya1\\Desktop\\chromedriver\\chromedriver.exe" );
		
		driver= new ChromeDriver();
}
	@Given("^user is on 'hotelBooking' page$")
	public void user_is_on_hotelBooking_page() {
	    // Write code here that turns the phrase above into concrete actions
	    driver.get("C:\\Users\\vdivya1\\test\\Mock\\HotekBooking.html");
	    bookingbean=new Hotelbookingbean(driver);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name()  {
	    // Write code here that turns the phrase above into concrete actions
	    bookingbean.setFisrtName("");
	    bookingbean.setConfirmButton();
	}

	@Then("^dispalys 'please fill the first name'$")
	public void dispalys_please_fill_the_first_name()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
		bookingbean.setLastName("");
		bookingbean.setConfirmButton();
	}

	@Then("^displays 'please fill the last name'$")
	public void displays_please_fill_the_last_name()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email()  {
	    // Write code here that turns the phrase above into concrete actions
	   bookingbean.setFisrtName("Divya");
	   bookingbean.setLastName("Veerala");
	   bookingbean.setEmail("");
	   bookingbean.setConfirmButton();
	}

	@Then("^displays 'please fill the email'$")
	public void displays_please_fill_the_email()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number()  {
	    // Write code here that turns the phrase above into concrete actions
	    bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please fill the mobile number'$")
	public void displays_please_fill_the_mobile_number()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Mobile No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("735869");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please enter valid mobile number'$")
	public void displays_please_enter_valid_mobile_number() {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter address$")
	public void user_does_not_enter_address() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^displays 'please enter Address'$")
	public void displays_please_enter_Address()  {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user does not enter city$")
	public void user_does_not_enter_city()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please enter City'$")
	public void displays_please_enter_City()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter state$")
	public void user_does_not_enter_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please enter State'$")
	public void displays_please_enter_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid number of persons staying'$")
	public void user_enters_invalid_number_of_persons_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^displays 'Please enter valid number of people staying'$")
	public void displays_Please_enter_valid_number_of_people_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("Tamilnadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please enter valid Card Holder Name'$")
	public void displays_please_enter_valid_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("Tamilnadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("Divya Veerala");
	    bookingbean.setDebitCardNumber("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please enter valid Debit Card$")
	public void displays_please_enter_valid_Debit_Card()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	

	@When("^user does not enter CVV value$")
	public void user_does_not_enter_CVV_value()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("Tamilnadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("Divya Veerala");
	    bookingbean.setDebitCardNumber("89884");
	    bookingbean.setCVV("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'please fill CVV number'$")
	public void displays_please_fill_CVV_number() {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the CVV";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("Tamilnadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("Divya Veerala");
	    bookingbean.setDebitCardNumber("89884");
	    bookingbean.setCVV("890");
	    bookingbean.setExperationmonth("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("Tamilnadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("Divya Veerala");
	    bookingbean.setDebitCardNumber("89884");
	    bookingbean.setCVV("890");
	    bookingbean.setExperationmonth("6");
	    bookingbean.setExperationyear("");
	    bookingbean.setConfirmButton();
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year()  {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the expiration year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid payment details$")
	public void user_enters_valid_payment_details()  {
	    // Write code here that turns the phrase above into concrete actions
		bookingbean.setFisrtName("Divya");
	    bookingbean.setLastName("Veerala");
	    bookingbean.setEmail("divyaveerala@gmail.com");
	    bookingbean.setMobileNo("7358698633");
	    bookingbean.setCity("Pune");
	    bookingbean.setState("TamilNadu");
	    bookingbean.setPersonCount(2);
	    bookingbean.setCardHolderName("Divya Veerala");
	    bookingbean.setDebitCardNumber("89884");
	    bookingbean.setCVV("890");
	    bookingbean.setExperationmonth("6");
	    bookingbean.setExperationyear("2019");
	    bookingbean.setConfirmButton();
	}
	

	@Then("^diplays 'Booking Completed'$")
	public void diplays_Booking_Completed()  {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:\\Users\\vdivya1\\test\\Mock\\login.html");
		driver.close();
	}

	
}