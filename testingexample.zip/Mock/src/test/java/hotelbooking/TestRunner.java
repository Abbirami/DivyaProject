package hotelbooking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features="C:\\Users\\vdivya1\\test\\Mock\\src\\test\\resources\\HotelBooking\\hotelbooking.feature",glue="stepdefinitions",dryRun=false) public class TestRunner {
}