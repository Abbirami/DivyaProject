package Hotelbean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Hotelbookingbean {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
   WebElement FisrtName;
	
	@FindBy(how=How.ID,using="btnPayment")
	@CacheLookup
	WebElement ConfirmButton;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement LastName;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement Email;
	
	@FindBy(css="input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement MobileNo;
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement City;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement State;

	@FindBy(how=How.NAME, using="persons")
	@CacheLookup
	int PersonCount;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[11]")
	@CacheLookup
	WebElement rooms;

	@FindBy(id ="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;

	@FindBy(name="debit")
	@CacheLookup
	WebElement debitCardNumber;

	@FindBy(name="cvv")
	@CacheLookup
	WebElement CVV;

	@FindBy(name="month")
	@CacheLookup
	WebElement Experationmonth;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement Experationyear;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFisrtName() {
		return FisrtName;
	}

	public void setFisrtName(String fisrtName) {
		this.FisrtName.sendKeys(fisrtName);
	}

	public WebElement getConfirmButton() {
		return ConfirmButton;
	}

	public void setConfirmButton() {
		this.ConfirmButton.click();
	}

	public WebElement getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		this.LastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.MobileNo.sendKeys( mobileNo);;
	}

	public WebElement getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City.sendKeys( city);
	}

	public WebElement getState() {
		return State;
	}

	public void setState(String state) {
		this.State.sendKeys(state);
	}

	public int getPersonCount() {
		return PersonCount;
	}

	public void setPersonCount(int personCount) {
		this.PersonCount = personCount;
	}

	public WebElement getRooms() {
		return rooms;
	}

	public void setRooms(WebElement rooms) {
		this.rooms = rooms;
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public WebElement getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);;
	}

	public WebElement getCVV() {
		return CVV;
	}

	public void setCVV(String cVV) {
		this.CVV.sendKeys(cVV);
	}

	public WebElement getExperationmonth() {
		return Experationmonth;
	}

	public void setExperationmonth(String experationmonth) {
		this.Experationmonth.sendKeys(experationmonth);
	}

	public WebElement getExperationyear() {
		return Experationyear;
	}

	public void setExperationyear(String experationyear) {
		this.Experationyear.sendKeys(experationyear);
	}

	public Hotelbookingbean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	
	
}



